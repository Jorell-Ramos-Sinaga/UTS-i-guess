using System.Collections;
using UnityEngine;

public class WaveSpawner : MonoBehaviour
{
    [Header("Referensi")]
    [SerializeField] private GameObject enemyPrefab;
    [SerializeField] private WaypointPath waypointPath;
    [Tooltip("Jalur kedua menuju base. Kosongkan jika map hanya punya 1 path.")]
    [SerializeField] private WaypointPath alternatePath;

    [Header("Path Perception")]
    [SerializeField] private bool useTowerPerception = true;
    [Tooltip("Tower dalam jarak ini dari garis path dihitung sebagai ancaman di jalur tersebut.")]
    [SerializeField] private float perceptionRadius = 7f;

    [Header("Wave Settings")]
    [SerializeField] private int totalWaves = 5;
    [SerializeField] private int enemiesPerWave = 5;
    [SerializeField] private float timeBetweenEnemies = 1.0f;
    [SerializeField] private float timeBetweenWaves = 5.0f;

    private int currentWaveIndex = 0;
    private bool isSpawning = false;

    private void Start()
    {
        StartCoroutine(SpawnAllWavesRoutine());
    }

    private IEnumerator SpawnAllWavesRoutine()
    {
        yield return new WaitForSeconds(2f); // Jeda persiapan sebelum gelombang 1

        while (currentWaveIndex < totalWaves)
        {
            currentWaveIndex++;
            Debug.Log($"--- Wave {currentWaveIndex} Dimulai ---");

            yield return StartCoroutine(SpawnWaveRoutine(enemiesPerWave + (currentWaveIndex * 2)));

            // Jeda antar wave
            yield return new WaitForSeconds(timeBetweenWaves);
        }

        Debug.Log("Semua wave telah dimunculkan!");
    }

    private IEnumerator SpawnWaveRoutine(int enemyCount)
    {
        isSpawning = true;

        for (int i = 0; i < enemyCount; i++)
        {
            SpawnEnemy();
            yield return new WaitForSeconds(timeBetweenEnemies);
        }

        isSpawning = false;
    }

    private void SpawnEnemy()
    {
        WaypointPath chosenPath = ChoosePath();
        if (enemyPrefab == null || chosenPath == null || chosenPath.points == null || chosenPath.points.Length == 0) return;

        Transform spawnPoint = chosenPath.points[0];
        if (spawnPoint == null) return;

        GameObject enemyObj = Instantiate(enemyPrefab, spawnPoint.position, spawnPoint.rotation);

        EnemyMovement movement = enemyObj.GetComponent<EnemyMovement>();
        if (movement != null)
        {
            movement.SetupPath(chosenPath.points);
        }
    }

    private WaypointPath ChoosePath()
    {
        if (!useTowerPerception || alternatePath == null)
        {
            return waypointPath;
        }

        WaypointPath saferPath = PathPerception.ChooseSaferPath(waypointPath, alternatePath, perceptionRadius);

        int threatA = PathPerception.CountTowersNearPath(waypointPath, perceptionRadius);
        int threatB = PathPerception.CountTowersNearPath(alternatePath, perceptionRadius);
        Debug.Log($"Enemy perception: Path1 towers={threatA}, Path2 towers={threatB}, pilih {(saferPath == waypointPath ? "Path 1" : "Path 2")}");

        return saferPath;
    }
}
